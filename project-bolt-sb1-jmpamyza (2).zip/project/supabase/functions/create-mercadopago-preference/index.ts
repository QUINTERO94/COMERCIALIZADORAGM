/*
  # Función Edge para crear preferencias de pago de Mercado Pago

  Esta función se encarga de:
  1. Recibir los datos del carrito desde el frontend
  2. Crear una preferencia de pago en Mercado Pago
  3. Devolver el init_point para redirigir al usuario al checkout

  ## Variables de entorno requeridas:
  - MERCADO_PAGO_ACCESS_TOKEN: Token de acceso de Mercado Pago (debe ser secreto)

  ## Uso:
  POST /functions/v1/create-mercadopago-preference
  Body: { items: CartItem[], payer?: PayerInfo, back_urls?: BackUrls }
*/

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  description?: string
}

interface PayerInfo {
  name?: string
  surname?: string
  email?: string
  phone?: {
    area_code?: string
    number?: string
  }
  identification?: {
    type?: string
    number?: string
  }
  address?: {
    street_name?: string
    street_number?: number
    zip_code?: string
  }
}

interface BackUrls {
  success?: string
  failure?: string
  pending?: string
}

interface MercadoPagoItem {
  id: string
  title: string
  description?: string
  picture_url?: string
  category_id?: string
  quantity: number
  currency_id: string
  unit_price: number
}

interface MercadoPagoPreference {
  items: MercadoPagoItem[]
  payer?: PayerInfo
  back_urls?: BackUrls
  auto_return?: string
  payment_methods?: {
    excluded_payment_methods?: Array<{ id: string }>
    excluded_payment_types?: Array<{ id: string }>
    installments?: number
  }
  notification_url?: string
  statement_descriptor?: string
  external_reference?: string
}

Deno.serve(async (req) => {
  console.log('=== INICIO DE FUNCIÓN MERCADO PAGO ===');
  console.log('Método:', req.method);
  console.log('URL:', req.url);
  
  // Manejar preflight CORS
  if (req.method === 'OPTIONS') {
    console.log('Respondiendo a preflight CORS');
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Verificar que sea una petición POST
    if (req.method !== 'POST') {
      console.log('Método no permitido:', req.method);
      return new Response(
        JSON.stringify({ error: 'Método no permitido' }),
        {
          status: 405,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    // Obtener el token de acceso de las variables de entorno
    const accessToken = Deno.env.get('MERCADO_PAGO_ACCESS_TOKEN')
    console.log('Token configurado:', accessToken ? 'SÍ' : 'NO');
    
    if (!accessToken) {
      console.error('ERROR CRÍTICO: MERCADO_PAGO_ACCESS_TOKEN no está configurado');
      return new Response(
        JSON.stringify({ 
          error: 'Token de Mercado Pago no configurado. Contacta al administrador.',
          details: 'La variable de entorno MERCADO_PAGO_ACCESS_TOKEN no está definida en Supabase'
        }),
        {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    // Parsear el cuerpo de la petición
    let requestBody;
    try {
      const bodyText = await req.text();
      console.log('Cuerpo de la petición recibido:', bodyText);
      requestBody = JSON.parse(bodyText);
    } catch (parseError) {
      console.error('Error al parsear el cuerpo de la petición:', parseError);
      return new Response(
        JSON.stringify({ 
          error: 'Formato de datos inválido',
          details: 'El cuerpo de la petición no es un JSON válido'
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    const { items, payer, back_urls } = requestBody;

    // Validar que se enviaron items
    if (!items || !Array.isArray(items) || items.length === 0) {
      console.log('Items inválidos:', items);
      return new Response(
        JSON.stringify({ 
          error: 'Se requieren items para crear la preferencia',
          details: 'El array de items está vacío o no es válido'
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    console.log('Items recibidos:', items.length);

    // Convertir los items del carrito al formato de Mercado Pago
    const mercadoPagoItems: MercadoPagoItem[] = items.map((item: CartItem) => ({
      id: item.id,
      title: item.name,
      description: item.description || item.name,
      quantity: item.quantity,
      currency_id: 'COP', // Pesos colombianos
      unit_price: Math.round(item.price), // Asegurar que sea un entero
    }))

    console.log('Items convertidos para Mercado Pago:', mercadoPagoItems);

    // Construir la preferencia de pago
    const preference: MercadoPagoPreference = {
      items: mercadoPagoItems,
      auto_return: 'approved',
      statement_descriptor: 'GYM SAS',
      external_reference: `order_${Date.now()}`,
    }

    // Agregar información del pagador si se proporciona
    if (payer && payer.email) {
      preference.payer = {
        name: payer.name,
        surname: payer.surname,
        email: payer.email,
        phone: payer.phone,
        address: payer.address
      }
      console.log('Información del pagador agregada');
    }

    // Agregar URLs de retorno
    const origin = req.headers.get('origin') || req.headers.get('referer')?.split('/').slice(0, 3).join('/') || 'http://localhost:5173';
    console.log('Origin detectado:', origin);

    if (back_urls && back_urls.success && back_urls.failure && back_urls.pending) {
      preference.back_urls = back_urls;
    } else {
      preference.back_urls = {
        success: `${origin}/payment/success`,
        failure: `${origin}/payment/failure`,
        pending: `${origin}/payment/pending`,
      }
    }

    console.log('URLs de retorno:', preference.back_urls);

    // Configurar métodos de pago
    preference.payment_methods = {
      installments: 12, // Máximo 12 cuotas
    }

    console.log('=== ENVIANDO PETICIÓN A MERCADO PAGO ===');
    console.log('Preferencia completa:', JSON.stringify(preference, null, 2));

    // Realizar la petición a la API de Mercado Pago
    const mercadoPagoResponse = await fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'User-Agent': 'GYM-SAS/1.0',
      },
      body: JSON.stringify(preference),
    })

    console.log('Respuesta de Mercado Pago - Status:', mercadoPagoResponse.status);
    console.log('Respuesta de Mercado Pago - Headers:', Object.fromEntries(mercadoPagoResponse.headers.entries()));

    if (!mercadoPagoResponse.ok) {
      const errorText = await mercadoPagoResponse.text()
      console.error('ERROR DE MERCADO PAGO:');
      console.error('Status:', mercadoPagoResponse.status);
      console.error('Status Text:', mercadoPagoResponse.statusText);
      console.error('Respuesta completa:', errorText);
      
      let errorDetails = errorText;
      try {
        const errorJson = JSON.parse(errorText);
        errorDetails = JSON.stringify(errorJson, null, 2);
      } catch (e) {
        // Si no es JSON válido, usar el texto tal como está
      }
      
      return new Response(
        JSON.stringify({ 
          error: 'Error al crear la preferencia de pago en Mercado Pago',
          status: mercadoPagoResponse.status,
          statusText: mercadoPagoResponse.statusText,
          details: errorDetails
        }),
        {
          status: mercadoPagoResponse.status,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    const mercadoPagoData = await mercadoPagoResponse.json()
    
    console.log('=== ÉXITO ===');
    console.log('Preferencia creada exitosamente:', mercadoPagoData.id);
    console.log('Init point:', mercadoPagoData.init_point);

    // Devolver la respuesta con el init_point
    return new Response(
      JSON.stringify({
        id: mercadoPagoData.id,
        init_point: mercadoPagoData.init_point,
        sandbox_init_point: mercadoPagoData.sandbox_init_point,
        external_reference: preference.external_reference,
        success: true
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )

  } catch (error) {
    console.error('=== ERROR GENERAL ===');
    console.error('Error completo:', error);
    console.error('Stack trace:', error.stack);
    
    return new Response(
      JSON.stringify({ 
        error: 'Error interno del servidor',
        message: error.message,
        details: 'Revisa los logs de la función para más detalles'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  }
})